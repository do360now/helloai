#!/usr/bin/env python3
"""Round 2 hidden bundle (semver patch duel). Usage: run_hidden.py SOLUTION_DIR [-v]; last stdout line is passed/total.
Case format (also the counterexample format):
 {"fn":"compare","args":[...],"expect":{"returns":X}|{"raises":"ValueError"|"TypeError"}, "as_tuple":bool?}
 For sort_versions, the harness also requires: input list unmodified and result is a new list object."""
import json, os, subprocess, sys

CHILD = r'''
import sys, json, importlib
sys.path.insert(0, sys.argv[1])
import semver
case = json.loads(sys.stdin.read())
args = case["args"]
if case.get("as_tuple"):
    args = [tuple(args[0])]
orig = [list(a) if isinstance(a, (list, tuple)) else a for a in args]
out = {}
try:
    r = getattr(semver, case["fn"])(*args)
    if case["fn"] == "parse":
        ok = (type(r) is tuple and len(r) == 5 and type(r[3]) is tuple and type(r[4]) is tuple
              and all(type(x) is int for x in r[:3]))
        out["shape_ok"] = ok
        out["returns"] = [r[0], r[1], r[2], list(r[3]), list(r[4])] if ok else repr(r)
    elif case["fn"] == "compare":
        out["returns"] = r if type(r) is int else repr(r)
    else:
        out["returns"] = r if type(r) is list else repr(r)
        out["same_obj"] = r is args[0]
    out["input_after"] = [list(a) if isinstance(a, (list, tuple)) else a for a in args]
    out["input_before"] = orig
except BaseException as e:
    if isinstance(e, ValueError): out["raises"] = "ValueError"
    elif isinstance(e, TypeError): out["raises"] = "TypeError"
    else: out["raises"] = "other:" + type(e).__name__
    out["input_after"] = [list(a) if isinstance(a, (list, tuple)) else a for a in args]
    out["input_before"] = orig
print(json.dumps(out))
'''


def run_case(sol, case, timeout=10):
    p = subprocess.run([sys.executable, "-c", CHILD, sol], input=json.dumps(case), capture_output=True,
                       text=True, timeout=timeout)
    if p.returncode != 0:
        return False, "crash: " + p.stderr.strip()[-200:]
    out = json.loads(p.stdout.strip().splitlines()[-1])
    if out["input_after"] != out["input_before"]:
        return False, "input mutated"
    exp = case["expect"]
    if "raises" in exp:
        return out.get("raises") == exp["raises"], "got %r" % (out,)
    if "raises" in out:
        return False, "raised %s" % out["raises"]
    if case["fn"] == "parse" and not out["shape_ok"]:
        return False, "bad shape %s" % out["returns"]
    if case["fn"] == "sort_versions" and out["same_obj"]:
        return False, "returned the argument object"
    return out["returns"] == exp["returns"] and json.dumps(out["returns"]) == json.dumps(exp["returns"]), "got %r" % (out["returns"],)


CASES = []


def add(fn, args, **expect):
    c = {"fn": fn, "args": args, "expect": expect}
    CASES.append(c)
    return c


def chain(vs):
    for a, b in zip(vs, vs[1:]):
        add("compare", [a, b], returns=-1)
        add("compare", [b, a], returns=1)
    add("compare", [vs[0], vs[0]], returns=0)
    n = len(vs)
    shuffled = vs[::-1]
    shuffled = shuffled[n // 2:] + shuffled[:n // 2]
    add("sort_versions", [shuffled], returns=list(vs))


chain(["1.0.0-alpha", "1.0.0-alpha.1", "1.0.0-alpha.beta", "1.0.0-beta", "1.0.0-beta.2", "1.0.0-beta.11", "1.0.0-rc.1", "1.0.0"])
chain(["1.0.0-0", "1.0.0-1", "1.0.0-2", "1.0.0-10", "1.0.0--", "1.0.0-0a", "1.0.0-1a", "1.0.0-A", "1.0.0-B", "1.0.0-a", "1.0.0-b", "1.0.0"])
chain(["0.0.0", "0.0.1", "0.1.0", "0.2.0", "0.10.0", "1.0.0", "2.0.0", "2.1.0", "2.1.1", "10.0.0-rc.1", "10.0.0", "10.0.1",
       "100000000000000000000.0.0"])
chain(["1.0.0-a", "1.0.0-a.0", "1.0.0-a.0.0", "1.0.0-a.0.1", "1.0.0-a.1", "1.0.0-a.b", "1.0.0-a.b.c", "1.0.0-alpha", "1.0.0-alphabet"])
chain(["1.0.0-99999999999999999999", "1.0.0-100000000000000000000", "1.0.0-a"])
chain(["1.2.3-0.0", "1.2.3-0.1", "1.2.3-1", "1.2.3"])

for a, b, r in [("1.0.0+1", "1.0.0+2", 0), ("1.0.0-a+x", "1.0.0-a", 0), ("1.0.0+build", "1.0.0", 0),
                ("1.0.0-a+z", "1.0.0-b+a", -1), ("1.0.0+z", "1.0.0-z+a", 1), ("1.0.0+a.b", "1.0.0+a", 0),
                ("1.0.0+001", "1.0.0+1", 0), ("2.0.0+a", "1.9.9+z", 1), ("1.0.0-a.1+x", "1.0.0-a.1+y", 0),
                ("1.0.0-0-0", "1.0.0-0-1", -1), ("1.0.0-1", "1.0.0--a", -1), ("1.0.0-a-b", "1.0.0-a", 1)]:
    add("compare", [a, b], returns=r)

# parse: valid
for s, r in [("1.2.3", [1, 2, 3, [], []]), ("0.0.0", [0, 0, 0, [], []]),
             ("1.0.0-alpha.1+build.5", [1, 0, 0, ["alpha", 1], ["build", "5"]]),
             ("1.0.0-0", [1, 0, 0, [0], []]), ("1.0.0-01a", [1, 0, 0, ["01a"], []]),
             ("1.0.0+01", [1, 0, 0, [], ["01"]]), ("1.0.0-a-b", [1, 0, 0, ["a-b"], []]),
             ("1.0.0--", [1, 0, 0, ["-"], []]), ("1.0.0-0-0", [1, 0, 0, ["0-0"], []]), ("1.0.0+-", [1, 0, 0, [], ["-"]]),
             ("123456789012345678901234567890.0.0", [123456789012345678901234567890, 0, 0, [], []]),
             ("1.0.0-123456789012345678901234567890", [1, 0, 0, [123456789012345678901234567890], []]),
             ("1.0.0-0.10.a.007a", [1, 0, 0, [0, 10, "a", "007a"], []]), ("10.20.30", [10, 20, 30, [], []]),
             ("1.0.0-rc.1+exp.sha.5114f85", [1, 0, 0, ["rc", 1], ["exp", "sha", "5114f85"]])]:
    add("parse", [s], returns=r)
# parse: invalid
for s in ["", "1", "1.2", "1.2.3.4", "v1.2.3", " 1.2.3", "1.2.3 ", "1.2.3\n", "\n1.2.3", "01.2.3", "1.02.3", "1.2.03", "-1.2.3", "1.2.-3",
          "1.0.0-", "1.0.0-01", "1.0.0-a.01", "1.0.0-a..b", "1.0.0+", "1.0.0-a+", "1.0.0+a..b", "1.0.0+a.", "1.0.0-a.",
          "1.2.3-a_b", "1.2.3+a_b", "１.２.３", "1.0.0-٣", "1.0.0+é", "1.0.0-a b", "1.0.0+a+b", "1.0.0-a-+", "1.0.0.",
          ".1.0.0", "1..0", "1.0.0-0.01", "1.0.0-00", "00.0.0", "1.2.3\r\n", "1.2.3 "]:
    add("parse", [s], raises="ValueError")
for v in [None, 123, 1.5, True, ["1.0.0"]]:
    add("parse", [v], raises="TypeError")
add("parse", [None], raises="TypeError")
add("compare", [1, "1.0.0"], raises="TypeError")
add("compare", ["1.0.0", None], raises="TypeError")
for a, b in [("1.0", "1.0.0"), ("1.0.0", "01.0.0"), ("1.0.0-01", "1.0.0"), ("1.0.0", "1.0.0\n"), ("", "")]:
    add("compare", [a, b], raises="ValueError")

# sort
add("sort_versions", [[]], returns=[])
add("sort_versions", [["1.0.0"]], returns=["1.0.0"])
add("sort_versions", [["1.1.0", "1.0.0"]], returns=["1.0.0", "1.1.0"])
add("sort_versions", [["1.0.0+b", "1.0.0+a", "1.0.0"]], returns=["1.0.0+b", "1.0.0+a", "1.0.0"])
add("sort_versions", [["1.0.0-b", "1.0.0+z", "1.0.0+a", "1.0.0-a"]], returns=["1.0.0-a", "1.0.0-b", "1.0.0+z", "1.0.0+a"])
add("sort_versions", [["1.0.0", "bogus"]], raises="ValueError")
add("sort_versions", [["1.0.0", 5]], raises="TypeError")
add("sort_versions", [["2.0.0", "1.0.0", "01.0.0"]], raises="ValueError")
add("sort_versions", [["1.0.0-10", "1.0.0-9", "1.0.0-9.1", "1.0.0-9.a"]], returns=["1.0.0-9", "1.0.0-9.1", "1.0.0-9.a", "1.0.0-10"])
add("sort_versions", [["1.0.0-b", "1.0.0-a", "1.0.0-a"]], returns=["1.0.0-a", "1.0.0-a", "1.0.0-b"])
c = add("sort_versions", [["1.1.0", "1.0.0", "1.0.0-rc.1"]], returns=["1.0.0-rc.1", "1.0.0", "1.1.0"])
c = add("sort_versions", [["2.0.0", "1.0.0"]], returns=["1.0.0", "2.0.0"]); c["as_tuple"] = True
c = add("sort_versions", [[]], returns=[]); c["as_tuple"] = True


def main():
    args = [a for a in sys.argv[1:] if a != "-v"]
    if len(args) != 1:
        print("usage: run_hidden.py SOLUTION_DIR [-v]", file=sys.stderr)
        return 2
    sol = os.path.abspath(args[0])
    passed = 0
    for c in CASES:
        try:
            ok, why = run_case(sol, c)
        except Exception as e:
            ok, why = False, "exception %r" % (e,)
        if ok:
            passed += 1
        elif "-v" in sys.argv:
            print("FAIL %s: %s" % (json.dumps(c), why), file=sys.stderr)
    print("%d/%d" % (passed, len(CASES)))


if __name__ == "__main__":
    main()
