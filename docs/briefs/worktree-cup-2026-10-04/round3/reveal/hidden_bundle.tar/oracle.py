"""Independent oracle built on Python's ast (for differential fuzzing only; shallow inputs)."""
import ast, re, sys
from fractions import Fraction
sys.set_int_max_str_digits(0)


class OErr(Exception):
    def __init__(self, kind): self.kind = kind


def evaluate(expr):
    if len(expr) > 1000:
        raise OErr("limit")
    if re.search(r"[^0-9.+\-*/%() \t]", expr):
        raise OErr("syntax")
    s = expr.strip(" \t")
    if re.search(r"\d\.(?!\d)|(?<!\d)\.", s):
        raise OErr("syntax")
    s2 = re.sub(r"\d+(?:\.\d+)?", lambda m: "N(%r)" % m.group(0), s)
    try:
        tree = ast.parse(s2, mode="eval").body
    except (SyntaxError, ValueError, RecursionError, MemoryError):
        raise OErr("syntax")

    def sz(x): return max(abs(x.numerator).bit_length(), x.denominator.bit_length())

    def chk(x):
        if sz(x) > 400000: raise OErr("limit")
        return x

    def ev(n):
        if isinstance(n, ast.Call):
            if not (isinstance(n.func, ast.Name) and n.func.id == "N" and len(n.args) == 1 and not n.keywords):
                raise OErr("syntax")
            return Fraction(n.args[0].value)
        if isinstance(n, ast.UnaryOp) and isinstance(n.op, (ast.USub, ast.UAdd)):
            v = ev(n.operand)
            return -v if isinstance(n.op, ast.USub) else v
        if isinstance(n, ast.BinOp):
            a = ev(n.left); b = ev(n.right); o = n.op
            if isinstance(o, ast.Add): return chk(a + b)
            if isinstance(o, ast.Sub): return chk(a - b)
            if isinstance(o, ast.Mult): return chk(a * b)
            if isinstance(o, (ast.Div, ast.FloorDiv, ast.Mod)):
                if b == 0: raise OErr("zero_div")
                return chk(Fraction(a / b if isinstance(o, ast.Div) else a // b if isinstance(o, ast.FloorDiv) else a % b))
            if isinstance(o, ast.Pow):
                if b.denominator != 1: raise OErr("domain")
                e = int(b)
                if a == 0 and e < 0: raise OErr("zero_div")
                if abs(e) * sz(a) > 200000: raise OErr("limit")
                return chk(a ** e)
        raise OErr("syntax")

    def check_syntax(n):  # reject any node kinds ev would reject, before evaluating (syntax beats eval errors)
        if isinstance(n, ast.Call):
            if not (isinstance(n.func, ast.Name) and n.func.id == "N" and len(n.args) == 1 and not n.keywords and isinstance(n.args[0], ast.Constant)):
                raise OErr("syntax")
        elif isinstance(n, ast.UnaryOp) and isinstance(n.op, (ast.USub, ast.UAdd)):
            check_syntax(n.operand)
        elif isinstance(n, ast.BinOp) and isinstance(n.op, (ast.Add, ast.Sub, ast.Mult, ast.Div, ast.FloorDiv, ast.Mod, ast.Pow)):
            check_syntax(n.left); check_syntax(n.right)
        else:
            raise OErr("syntax")
    check_syntax(tree)
    x = ev(tree)
    return str(x.numerator) if x.denominator == 1 else "%d/%d" % (x.numerator, x.denominator)
