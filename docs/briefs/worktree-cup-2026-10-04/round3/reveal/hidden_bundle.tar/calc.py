"""Exact rational expression evaluator (reference)."""
import sys
from fractions import Fraction

sys.setrecursionlimit(20000)
if hasattr(sys, "set_int_max_str_digits"):
    sys.set_int_max_str_digits(0)

MAX_LEN = 1000
MAX_BITS = 400_000
MAX_POW_COST = 200_000


class ExprError(Exception):
    def __init__(self, kind, message=""):
        Exception.__init__(self, "%s: %s" % (kind, message))
        self.kind = kind


def _tokens(s):
    out, i, n = [], 0, len(s)
    while i < n:
        c = s[i]
        if c in " \t":
            i += 1
        elif c in "0123456789":
            j = i
            while j < n and s[j] in "0123456789":
                j += 1
            if j < n and s[j] == ".":
                k = j + 1
                if k >= n or s[k] not in "0123456789":
                    raise ExprError("syntax", "bad decimal")
                while k < n and s[k] in "0123456789":
                    k += 1
                out.append(("num", Fraction(int(s[i:j] + s[j + 1:k]), 10 ** (k - j - 1))))
                i = k
            else:
                out.append(("num", Fraction(int(s[i:j]))))
                i = j
        elif c == "*" and s[i:i + 2] == "**":
            out.append(("op", "**"))
            i += 2
        elif c == "/" and s[i:i + 2] == "//":
            out.append(("op", "//"))
            i += 2
        elif c in "+-*/%()":
            out.append(("op", c))
            i += 1
        else:
            raise ExprError("syntax", "bad character")
    return out


class _P:
    def __init__(self, toks):
        self.t = toks
        self.i = 0

    def peek(self):
        return self.t[self.i] if self.i < len(self.t) else (None, None)

    def eat(self):
        tok = self.t[self.i]
        self.i += 1
        return tok

    # AST: ("num", v) ("neg", x) ("pos", x) (op, l, r)
    def expr(self):
        left = self.term()
        while self.peek() in (("op", "+"), ("op", "-")):
            op = self.eat()[1]
            left = (op, left, self.term())
        return left

    def term(self):
        left = self.unary()
        while self.peek() in (("op", "*"), ("op", "/"), ("op", "//"), ("op", "%")):
            op = self.eat()[1]
            left = (op, left, self.unary())
        return left

    def unary(self):
        if self.peek() == ("op", "-"):
            self.eat()
            return ("neg", self.unary())
        if self.peek() == ("op", "+"):
            self.eat()
            return ("pos", self.unary())
        return self.power()

    def power(self):
        base = self.atom()
        if self.peek() == ("op", "**"):
            self.eat()
            return ("**", base, self.unary())
        return base

    def atom(self):
        kind, v = self.peek()
        if kind == "num":
            self.eat()
            return ("num", v)
        if (kind, v) == ("op", "("):
            self.eat()
            e = self.expr()
            if self.peek() != ("op", ")"):
                raise ExprError("syntax", "expected )")
            self.eat()
            return e
        raise ExprError("syntax", "unexpected token")


def _size(x):
    return max(abs(x.numerator).bit_length(), x.denominator.bit_length())


def _chk(x):
    if _size(x) > MAX_BITS:
        raise ExprError("limit", "result too large")
    return x


def _eval(node):
    k = node[0]
    if k == "num":
        return node[1]
    if k == "neg":
        return -_eval(node[1])
    if k == "pos":
        return _eval(node[1])
    a = Fraction(_eval(node[1]))
    b = Fraction(_eval(node[2]))
    if k == "+":
        return _chk(a + b)
    if k == "-":
        return _chk(a - b)
    if k == "*":
        return _chk(a * b)
    if k in ("/", "//", "%"):
        if b == 0:
            raise ExprError("zero_div", "division by zero")
        return _chk(Fraction(a / b if k == "/" else a // b if k == "//" else a % b))
    # power
    if b.denominator != 1:
        raise ExprError("domain", "non-integer exponent")
    e = b.numerator
    if a == 0 and e < 0:
        raise ExprError("zero_div", "0 to a negative power")
    if abs(e) * _size(a) > MAX_POW_COST:
        raise ExprError("limit", "power too large")
    return _chk(Fraction(a) ** e)


def _fmt(x):
    return str(x.numerator) if x.denominator == 1 else "%d/%d" % (x.numerator, x.denominator)


def evaluate(expr):
    if not isinstance(expr, str):
        raise TypeError("expr must be a str")
    if len(expr) > MAX_LEN:
        raise ExprError("limit", "expression too long")
    toks = _tokens(expr)
    p = _P(toks)
    tree = p.expr()
    if p.i != len(toks):
        raise ExprError("syntax", "trailing tokens")
    return _fmt(_eval(tree))
