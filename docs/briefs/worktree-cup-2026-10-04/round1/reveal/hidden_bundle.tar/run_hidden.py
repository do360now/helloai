#!/usr/bin/env python3
"""Hidden bundle for the Worktree Cup. Usage: run_hidden.py SOLUTION (file or dir containing hub_scoreboard.py).
Prints 'passed/total' as its last stdout line. Add -v for per-case detail on stderr."""
import json, os, subprocess, sys, tempfile

P = ("astra", "grok", "opus")


def R(rid="R1", passed=(10, 10, 10), total=10, ce=(), fo=(), **over):
    d = {"schema_version": 1, "round_id": rid, "players": list(P),
         "hidden_tests": {p: {"passed": a, "total": total} for p, a in zip(P, passed)},
         "counterexamples": [{"by": b, "against": g, "validated": v} for b, g, v in ce],
         "forfeits": list(fo)}
    d.update(over)
    return d


def J(d):
    return json.dumps(d)


def mut(fn, **kw):
    d = R(**kw)
    fn(d)
    return d


def fmt(x):
    return str(int(x)) if x == int(x) else "%.1f" % x


def table(st, rids):
    rids = sorted(rids)
    rows = [["place", "player", "points", "breaks"] + rids]
    for pl, pt, br, rd in st:
        rows.append(["", pl, fmt(pt), str(br)] + [fmt(rd[r]) for r in rids])
    pts = [r[2] for r in rows[1:]]
    for i, r in enumerate(rows[1:]):
        r[0] = str(1 + sum(1 for q in pts if float(q) > float(r[2])))
    w = [max(len(r[c]) for r in rows) for c in range(len(rows[0]))]
    return "".join("  ".join(c.ljust(w[i]) for i, c in enumerate(r)).rstrip() + "\n" for r in rows)


CASES = []


def ok(name, rounds, expect):
    """rounds: list of (filename, content); expect: {player: (points, breaks, {rid: pts})} """
    CASES.append(("ok", name, rounds, expect))


def err(name, rounds, extra=None, raw_args=None):
    CASES.append(("err", name, rounds, extra if extra is not None else raw_args))


def one(d, fn="r.json"):
    return [(fn, J(d))]


def E(a, g, o):
    return {"astra": a, "grok": g, "opus": o}


def S(pt, br, **rd):
    return (pt, br, rd)


# ---- scoring (single round)
ok("ordinary", one(R(passed=(18, 20, 12), total=20, ce=[("astra", "grok", True)])),
   E(S(2, 1, R1=2), S(3, 0, R1=3), S(1, 0, R1=1)))
ok("three_way_tie", one(R()), E(S(2, 0, R1=2), S(2, 0, R1=2), S(2, 0, R1=2)))
ok("tie_first_forfeit", one(R(passed=(20, 20, 5), total=20, fo=["opus"])),
   E(S(2.5, 0, R1=2.5), S(2.5, 0, R1=2.5), S(0, 0, R1=0)))
ok("all_forfeit", one(R(passed=(1, 2, 3), fo=list(P))), E(S(0, 0, R1=0), S(0, 0, R1=0), S(0, 0, R1=0)))
ok("tie_second", one(R(passed=(10, 4, 4))), E(S(3, 0, R1=3), S(1.5, 0, R1=1.5), S(1.5, 0, R1=1.5)))
ok("tie_first_two_third_lower", one(R(passed=(4, 9, 9))), E(S(1, 0, R1=1), S(2.5, 0, R1=2.5), S(2.5, 0, R1=2.5)))
ok("sole_eligible", one(R(passed=(0, 0, 0), fo=["astra", "opus"])), E(S(0, 0, R1=0), S(3, 0, R1=3), S(0, 0, R1=0)))
ok("sole_eligible_lowest_passed", one(R(passed=(10, 0, 10), fo=["astra", "opus"])), E(S(0, 0, R1=0), S(3, 0, R1=3), S(0, 0, R1=0)))
ok("two_eligible_ranked", one(R(passed=(9, 2, 10), fo=["astra"])), E(S(0, 0, R1=0), S(2, 0, R1=2), S(3, 0, R1=3)))
ok("two_eligible_tied_forfeit_has_best", one(R(passed=(3, 3, 10), fo=["opus"])), E(S(2.5, 0, R1=2.5), S(2.5, 0, R1=2.5), S(0, 0, R1=0)))
ok("forfeit_passed_ignored", one(R(passed=(1, 2, 10), fo=["opus"])), E(S(2, 0, R1=2), S(3, 0, R1=3), S(0, 0, R1=0)))
ok("break_resolves_tie", one(R(passed=(7, 7, 3), ce=[("grok", "opus", True)])), E(S(2, 0, R1=2), S(3, 1, R1=3), S(1, 0, R1=1)))
ok("break_cannot_beat_passed", one(R(passed=(5, 6, 1), ce=[("astra", "grok", True), ("astra", "opus", True)])),
   E(S(2, 2, R1=2), S(3, 0, R1=3), S(1, 0, R1=1)))
ok("unvalidated_break_ignored", one(R(passed=(7, 7, 3), ce=[("grok", "opus", False)])), E(S(2.5, 0, R1=2.5), S(2.5, 0, R1=2.5), S(0 + 0, 0, R1=0) if False else S(1, 0, R1=1)))
ok("break_against_forfeit_ignored", one(R(passed=(7, 7, 3), ce=[("grok", "opus", True)], fo=["opus"])),
   E(S(2.5, 0, R1=2.5), S(2.5, 0, R1=2.5), S(0, 0, R1=0)))
ok("break_by_forfeit_ignored", one(R(passed=(7, 7, 7), ce=[("astra", "grok", True)], fo=["astra"])),
   E(S(0, 0, R1=0), S(2.5, 0, R1=2.5), S(2.5, 0, R1=2.5)))
ok("break_counts_for_ranking_tie_three_levels", one(R(passed=(8, 8, 8), ce=[("astra", "grok", True), ("astra", "opus", True), ("grok", "opus", True)])),
   E(S(3, 2, R1=3), S(2, 1, R1=2), S(1, 0, R1=1)))
ok("break_tie_still_tied", one(R(passed=(8, 8, 8), ce=[("astra", "grok", True), ("grok", "opus", True), ("opus", "astra", True)])),
   E(S(2, 1, R1=2), S(2, 1, R1=2), S(2, 1, R1=2)))
ok("break_partial_tie_for_first", one(R(passed=(8, 8, 3), ce=[("astra", "opus", True), ("grok", "opus", True)])),
   E(S(2.5, 1, R1=2.5), S(2.5, 1, R1=2.5), S(1, 0, R1=1)))
ok("breaks_three_ties_across_total_difference", one(R(passed=(0, 0, 1), total=1)), E(S(1.5, 0, R1=1.5), S(1.5, 0, R1=1.5), S(3, 0, R1=3)))
ok("big_ints", one(R(passed=(10**20, 10**20 - 1, 5), total=10**20)), E(S(3, 0, R1=3), S(2, 0, R1=2), S(1, 0, R1=1)))
ok("players_order_irrelevant", one(R(passed=(1, 2, 3), players=["opus", "astra", "grok"])), E(S(1, 0, R1=1), S(2, 0, R1=2), S(3, 0, R1=3)))
ok("minus_zero_ok", [("r.json", J(R(passed=(1, 2, 3))).replace('"astra": {"passed": 1', '"astra": {"passed": -0'))], E(S(1, 0, R1=1), S(2, 0, R1=2), S(3, 0, R1=3)))
ok("whitespace_pretty_input", [("r.json", "\n  " + json.dumps(R(passed=(1, 2, 3)), indent=4) + "\n\n")], E(S(1, 0, R1=1), S(2, 0, R1=2), S(3, 0, R1=3)))
ok("unicode_escape_round_id", [("r.json", J(R(rid="Ré")))], E(S(2, 0, **{"Ré": 2}), S(2, 0, **{"Ré": 2}), S(2, 0, **{"Ré": 2})))
ok("unused_counterexample_lists_all_pairs",
   one(R(passed=(5, 5, 5), ce=[(a, b, True) for a in P for b in P if a != b])),
   E(S(2, 2, R1=2), S(2, 2, R1=2), S(2, 2, R1=2)))
ok("zero_passed_zero_points_are_not_forfeit", one(R(passed=(0, 0, 0))), E(S(2, 0, R1=2), S(2, 0, R1=2), S(2, 0, R1=2)))

ok("break_separates_tie", one(R(passed=(8, 8, 8), ce=[("astra", "grok", True)])), E(S(3, 1, R1=3), S(1.5, 0, R1=1.5), S(1.5, 0, R1=1.5)))

# ---- multi round
m1 = R("R1", (5, 9, 9), 10)
m2 = R("R2", (10, 10, 7), 10, [("opus", "astra", True), ("astra", "grok", True), ("grok", "astra", False)])
m10 = R("R10", (20, 18, 18), 20, [("grok", "opus", True), ("opus", "grok", True), ("astra", "opus", True)])
ok("multi_codepoint_order", [("a.json", J(m10)), ("b.json", J(m2)), ("c.json", J(m1))],
   E(S(7, 2, R1=1, R10=3, R2=3), S(6, 1, R1=2.5, R10=1.5, R2=2), S(5, 2, R1=2.5, R10=1.5, R2=1)))
ok("multi_overall_tie_competition_rank",
   [("a.json", J(R("A", (9, 9, 1), 10, [("astra", "opus", True)]))), ("b.json", J(R("B", (9, 9, 1), 10, [("grok", "opus", True)])))],
   E(S(5, 1, A=3, B=2), S(5, 1, A=2, B=3), S(2, 0, A=1, B=1)))
ok("multi_different_totals_across_rounds", [("a.json", J(R("x", (1, 2, 3), 3))), ("b.json", J(R("y", (100, 0, 0), 100)))],
   E(S(4, 0, x=1, y=3), S(3.5, 0, x=2, y=1.5), S(4.5, 0, x=3, y=1.5)))
ok("multi_uppercase_before_lowercase_ids", [("a.json", J(R("a"))), ("b.json", J(R("B"))), ("c.json", J(R("_")))],
   E(S(6, 0, a=2, B=2, **{"_": 2}), S(6, 0, a=2, B=2, **{"_": 2}), S(6, 0, a=2, B=2, **{"_": 2})))
ok("multi_nonascii_id_order", [("a.json", J(R("z"))), ("b.json", J(R("é"))), ("c.json", J(R("Z")))],
   E(S(6, 0, **{"z": 2, "é": 2, "Z": 2}), S(6, 0, **{"z": 2, "é": 2, "Z": 2}), S(6, 0, **{"z": 2, "é": 2, "Z": 2})))
ok("multi_forfeit_each_round", [("a.json", J(R("R1", (3, 2, 1), fo=["astra"]))), ("b.json", J(R("R2", (3, 2, 1), fo=["grok"])))],
   E(S(3, 0, R1=0, R2=3), S(3, 0, R1=3, R2=0), S(4, 0, R1=2, R2=2)))
ok("multi_breaks_sum", [("a.json", J(R("R1", (5, 5, 5), ce=[("astra", "grok", True)]))), ("b.json", J(R("R2", (5, 5, 5), ce=[("astra", "opus", True)])))],
   E(S(6, 2, R1=3, R2=3), S(3, 0, R1=1.5, R2=1.5) if False else S(3, 0, R1=1.5, R2=1.5), S(3, 0, R1=1.5, R2=1.5)))

# ---- errors
def bad(name, d):
    err(name, one(d))


bad("schema_version_2", R(schema_version=2))
bad("schema_version_string", R(schema_version="1"))
bad("schema_version_float", R(schema_version=1.0))
bad("schema_version_true", R(schema_version=True))
bad("round_id_empty", R(rid=""))
bad("round_id_number", R(rid=1))
bad("round_id_null", R(rid=None))
bad("players_dup", R(players=["astra", "astra", "opus"]))
bad("players_missing", R(players=["astra", "grok"]))
bad("players_extra", R(players=["astra", "grok", "opus", "zed"]))
bad("players_case", R(players=["Astra", "grok", "opus"]))
bad("players_not_list", R(players="astra,grok,opus"))
bad("passed_gt_total", R(passed=(11, 1, 1)))
bad("passed_negative", R(passed=(-1, 1, 1)))
bad("total_zero", R(passed=(0, 0, 0), total=0))
bad("total_negative", R(passed=(0, 0, 0), total=-3))
bad("passed_bool", R(passed=(True, 1, 1)))
bad("total_bool", mut(lambda d: d["hidden_tests"]["grok"].update(total=True), passed=(1, 1, 1), total=1))
bad("passed_string", R(passed=("1", 1, 1)))
bad("passed_null", R(passed=(None, 1, 1)))
bad("passed_float_nonintegral", R(passed=(1.5, 1, 1)))
bad("unequal_totals", mut(lambda d: d["hidden_tests"]["opus"].update(total=11)))
bad("unequal_totals_forfeited_player", mut(lambda d: d["hidden_tests"]["opus"].update(total=11), fo=["opus"]))
bad("forfeited_invalid_passed", mut(lambda d: d["hidden_tests"]["opus"].update(passed=99), fo=["opus"]))
bad("forfeited_negative_passed", mut(lambda d: d["hidden_tests"]["opus"].update(passed=-1), fo=["opus"]))
bad("hidden_missing_player", mut(lambda d: d["hidden_tests"].pop("opus")))
bad("hidden_extra_player", mut(lambda d: d["hidden_tests"].update(zed={"passed": 1, "total": 10})))
bad("hidden_entry_extra_field", mut(lambda d: d["hidden_tests"]["grok"].update(extra=1)))
bad("hidden_entry_missing_total", mut(lambda d: d["hidden_tests"]["grok"].pop("total")))
bad("hidden_not_object", R(hidden_tests=[]))
bad("ce_self", R(ce=[("astra", "astra", True)]))
bad("ce_unknown_by", R(ce=[("zed", "astra", True)]))
bad("ce_unknown_against", R(ce=[("astra", "zed", True)]))
bad("ce_duplicate_pair", R(ce=[("astra", "grok", True), ("astra", "grok", True)]))
bad("ce_duplicate_pair_mixed_validated", R(ce=[("astra", "grok", True), ("astra", "grok", False)]))
bad("ce_validated_not_bool", R(counterexamples=[{"by": "astra", "against": "grok", "validated": 1}]))
bad("ce_validated_string", R(counterexamples=[{"by": "astra", "against": "grok", "validated": "true"}]))
bad("ce_missing_validated", R(counterexamples=[{"by": "astra", "against": "grok"}]))
bad("ce_extra_field", R(counterexamples=[{"by": "astra", "against": "grok", "validated": True, "note": "x"}]))
bad("ce_not_list", R(counterexamples={}))
bad("ce_entry_not_object", R(counterexamples=["astra"]))
bad("forfeits_unknown", R(fo=["zed"]))
bad("forfeits_dup", R(fo=["opus", "opus"]))
bad("forfeits_not_list", R(forfeits="opus"))
bad("forfeits_entry_not_string", R(forfeits=[1]))
bad("unknown_top_field", R(extra=1))
bad("missing_counterexamples", mut(lambda d: d.pop("counterexamples")))
bad("missing_forfeits", mut(lambda d: d.pop("forfeits")))
bad("missing_round_id", mut(lambda d: d.pop("round_id")))
bad("missing_schema_version", mut(lambda d: d.pop("schema_version")))
bad("missing_hidden", mut(lambda d: d.pop("hidden_tests")))
bad("missing_players", mut(lambda d: d.pop("players")))
base = J(R(passed=(1, 2, 3)))
E123 = E(S(1, 0, R1=1), S(2, 0, R1=2), S(3, 0, R1=3))
ok("integral_float_passed_1_0", [("r.json", base.replace('"passed": 1,', '"passed": 1.0,'))], E123)
ok("integral_float_total_exp", [("r.json", base.replace('"total": 10}', '"total": 1e1}', 1).replace('"total": 10}', '"total": 10.0}'))], E123)
ok("integral_float_upper_exp", [("r.json", base.replace('"passed": 2,', '"passed": 2E0,'))], E123)
ok("integral_float_negzero", [("r.json", base.replace('"passed": 1,', '"passed": -0.0,'))], E123)
ok("integral_float_all_fields", [("r.json", J(R(passed=(18, 20, 12), total=20)).replace('"passed": 18', '"passed": 18.0').replace('"total": 20', '"total": 2.0e1'))], E(S(2, 0, R1=2), S(3, 0, R1=3), S(1, 0, R1=1)))
err("float_nonintegral_total", [("r.json", base.replace('"total": 10}', '"total": 10.5}', 1))])
err("float_nonintegral_small_exp", [("r.json", base.replace('"passed": 1,', '"passed": 1e-1,'))])
err("float_nonintegral_trailing", [("r.json", base.replace('"passed": 2,', '"passed": 2.0000001,'))])
err("float_integral_but_gt_total", [("r.json", base.replace('"passed": 1,', '"passed": 1.1e1,'))])
err("float_zero_total", [("r.json", J(R(passed=(0, 0, 0), total=0)).replace('"total": 0', '"total": 0.0'))])
err("nan", [("r.json", base.replace('"passed": 1,', '"passed": NaN,'))])
err("infinity", [("r.json", base.replace('"passed": 1,', '"passed": Infinity,'))])
err("neg_infinity", [("r.json", base.replace('"passed": 1,', '"passed": -Infinity,'))])
err("leading_zero", [("r.json", base.replace('"passed": 1,', '"passed": 01,'))])
err("plus_sign", [("r.json", base.replace('"passed": 1,', '"passed": +1,'))])
err("dup_key_top", [("r.json", base[:-1] + ', "round_id": "R9"}')])
err("dup_key_nested", [("r.json", base.replace('"astra": {"passed": 1, "total": 10}', '"astra": {"passed": 1, "passed": 1, "total": 10}'))])
err("dup_key_hidden_players", [("r.json", base.replace('"hidden_tests": {', '"hidden_tests": {"astra": {"passed": 1, "total": 10}, '))])
err("dup_key_in_counterexample", [("r.json", J(R(ce=[("astra", "grok", True)])).replace('"validated": true', '"validated": true, "validated": false'))])
err("invalid_json_trailing_comma", [("r.json", base[:-1] + ",}")])
err("invalid_json_truncated", [("r.json", base[:-5])])
err("invalid_json_trailing_garbage", [("r.json", base + " x")])
err("invalid_two_documents", [("r.json", base + base)])
err("empty_file", [("r.json", "")])
err("top_level_array", [("r.json", "[" + base + "]")])
err("top_level_null", [("r.json", "null")])
err("bom", [("r.json", b"\xef\xbb\xbf" + base.encode())])
err("invalid_utf8", [("r.json", b'{"round_id": "\xff"}')])
err("single_quotes", [("r.json", base.replace('"', "'"))])
err("dup_round_id", [("a.json", J(R("R1"))), ("b.json", J(R("R1", (1, 2, 3))))])
err("same_file_twice", [("a.json", J(R("R1")))], extra="dup")
err("one_good_one_bad", [("a.json", J(R("R1"))), ("b.json", J(R("R2", passed=(11, 1, 1))))])
err("one_bad_first", [("a.json", J(R("R2", passed=(11, 1, 1)))), ("b.json", J(R("R1")))])
err("missing_file", [("a.json", J(R("R1")))], extra="missing")
err("directory_as_file", [], extra="dirarg")
err("no_results_args", [], extra="noargs")
err("format_xml", [("a.json", J(R("R1")))], extra="fmt-xml")
err("format_uppercase", [("a.json", J(R("R1")))], extra="fmt-TABLE")
err("unknown_flag", [("a.json", J(R("R1")))], extra="unknown-flag")
err("results_missing_value", [], extra="results-no-value")
err("format_missing_value", [("a.json", J(R("R1")))], extra="format-no-value")


def locate(sol):
    if os.path.isdir(sol):
        sol = os.path.join(sol, "hub_scoreboard.py")
    return os.path.abspath(sol)


def run_case(sol, case):
    kind, name, files, extra = case
    with tempfile.TemporaryDirectory() as td:
        paths = []
        for fn, content in files:
            p = os.path.join(td, fn)
            with open(p, "wb") as f:
                f.write(content if isinstance(content, bytes) else content.encode("utf-8"))
            paths.append(p)

        def call(args):
            r = subprocess.run([sys.executable, sol] + args, cwd=td, capture_output=True, timeout=15)
            return r.returncode, r.stdout.decode("utf-8", "replace"), r.stderr.decode("utf-8", "replace")

        res = []
        for p in paths:
            res += ["--results", p]
        if kind == "err":
            if extra == "dup":
                res = res + res
            elif extra == "missing":
                res = res + ["--results", os.path.join(td, "nope.json")]
            elif extra == "dirarg":
                res = ["--results", td]
            elif extra == "noargs":
                res = []
            elif extra == "fmt-xml":
                res += ["--format", "xml"]
            elif extra == "fmt-TABLE":
                res += ["--format", "TABLE"]
            elif extra == "unknown-flag":
                res += ["--bogus"]
            elif extra == "results-no-value":
                res = ["--results"]
            elif extra == "format-no-value":
                res += ["--format"]
            for fm in ([[]] if extra not in (None,) and extra != "dup" and extra != "missing" else [[], ["--format", "json"], ["--format", "table"]]):
                code, out, e = call(res + fm)
                if code != 2 or out != "" or not e.strip():
                    return "exit=%s stdout=%r stderr=%r (args extra %r)" % (code, out[:80], e[:80], fm)
            return None
        exp = extra
        rids = sorted({r for p in P for r in exp[p][2]})
        order = sorted(P, key=lambda p: (-exp[p][0], p))
        for fm in ([], ["--format", "table"], ["--format", "json"]):
            code, out, e = call(res + fm)
            if code != 0:
                return "exit=%s stderr=%r" % (code, e[:120])
            if fm[-1:] == ["json"]:
                try:
                    j = json.loads(out)
                except ValueError as x:
                    return "bad json: %s" % x
                st = j.get("standings") if isinstance(j, dict) and set(j) == {"standings"} else None
                if not isinstance(st, list) or [s.get("player") for s in st] != order:
                    return "standings/order wrong: %r" % (out[:200],)
                for s in st:
                    p = s["player"]
                    if set(s) != {"place", "player", "points", "breaks", "rounds"}:
                        return "entry keys %r" % sorted(s)
                    for k in ("place", "points", "breaks"):
                        if isinstance(s[k], bool) or not isinstance(s[k], (int, float)):
                            return "type of %s" % k
                    place = 1 + sum(1 for q in P if exp[q][0] > exp[p][0])
                    if s["place"] != place or int(s["place"]) != s["place"]:
                        return "place %r != %r for %s" % (s["place"], place, p)
                    if s["points"] != exp[p][0] or s["breaks"] != exp[p][1] or int(s["breaks"]) != s["breaks"]:
                        return "%s points/breaks %r/%r" % (p, s["points"], s["breaks"])
                    rd = s["rounds"]
                    if not isinstance(rd, dict) or set(rd) != set(exp[p][2]) or any(
                            isinstance(v, bool) or not isinstance(v, (int, float)) or v != exp[p][2][k] for k, v in rd.items()):
                        return "%s rounds %r" % (p, rd)
            else:
                want = table([(p, exp[p][0], exp[p][1], exp[p][2]) for p in order], rids)
                if out != want:
                    return "table mismatch:\n--got--\n%s--want--\n%s" % (out, want)
        return None


def main():
    args = [a for a in sys.argv[1:] if a != "-v"]
    verbose = "-v" in sys.argv
    if len(args) != 1:
        print("usage: run_hidden.py SOLUTION [-v]", file=sys.stderr)
        return 2
    sol = locate(args[0])
    passed = 0
    for c in CASES:
        try:
            fail = run_case(sol, c)
        except Exception as e:  # timeout etc
            fail = "exception: %r" % (e,)
        if fail is None:
            passed += 1
        elif verbose:
            print("FAIL %s: %s" % (c[1], fail), file=sys.stderr)
    print("%d/%d" % (passed, len(CASES)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
