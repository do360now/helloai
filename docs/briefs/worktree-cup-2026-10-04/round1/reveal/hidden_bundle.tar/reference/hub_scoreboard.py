#!/usr/bin/env python3
"""Reference implementation of hub_scoreboard (CUP-SETTER)."""
import argparse
import decimal
import json
import sys

PLAYERS = ("astra", "grok", "opus")


class Invalid(Exception):
    pass


def _pairs(pairs):
    d = {}
    for k, v in pairs:
        if k in d:
            raise Invalid("duplicate key %r" % k)
        d[k] = v
    return d


def _bad_const(name):
    raise Invalid("invalid number %s" % name)


def _float(tok):
    return decimal.Decimal(tok)


def load(path):
    try:
        with open(path, "rb") as f:
            raw = f.read()
        text = raw.decode("utf-8")
    except (OSError, UnicodeDecodeError) as e:
        raise Invalid("%s: cannot read: %s" % (path, e))
    try:
        return json.loads(text, object_pairs_hook=_pairs,
                          parse_constant=_bad_const, parse_float=_float)
    except Invalid as e:
        raise Invalid("%s: %s" % (path, e))
    except (ValueError, RecursionError) as e:
        raise Invalid("%s: invalid JSON: %s" % (path, e))


def is_int(v):
    return isinstance(v, int) and not isinstance(v, bool)


def to_int(v, what):
    """Integer-valued JSON number (1, 1.0, 1e1, -0) -> int; anything else invalid."""
    if is_int(v):
        return v
    if isinstance(v, decimal.Decimal) and v.is_finite() and v.adjusted() <= 1000 \
            and v == v.to_integral_value():
        return int(v)
    raise Invalid("%s must be an integer-valued number" % what)


def need_obj(v, keys, what):
    if not isinstance(v, dict):
        raise Invalid("%s must be an object" % what)
    if set(v) != set(keys):
        raise Invalid("%s must have exactly keys %s" % (what, sorted(keys)))


def validate(doc):
    need_obj(doc, ["schema_version", "round_id", "players", "hidden_tests",
                   "counterexamples", "forfeits"], "round")
    if not is_int(doc["schema_version"]) or doc["schema_version"] != 1:
        raise Invalid("schema_version must be integer 1")
    rid = doc["round_id"]
    if not isinstance(rid, str) or rid == "":
        raise Invalid("round_id must be a nonempty string")
    pl = doc["players"]
    if (not isinstance(pl, list) or len(pl) != 3
            or not all(isinstance(p, str) for p in pl)
            or sorted(pl) != sorted(PLAYERS)):
        raise Invalid("players must contain astra, grok, opus exactly once")
    ht = doc["hidden_tests"]
    need_obj(ht, PLAYERS, "hidden_tests")
    totals = set()
    for p in PLAYERS:
        need_obj(ht[p], ["passed", "total"], "hidden_tests.%s" % p)
        a = ht[p]["passed"] = to_int(ht[p]["passed"], "passed")
        t = ht[p]["total"] = to_int(ht[p]["total"], "total")
        if t <= 0 or a < 0 or a > t:
            raise Invalid("need 0 <= passed <= total and total > 0")
        totals.add(t)
    if len(totals) != 1:
        raise Invalid("totals differ between players")
    ce = doc["counterexamples"]
    if not isinstance(ce, list):
        raise Invalid("counterexamples must be an array")
    seen = set()
    for e in ce:
        need_obj(e, ["by", "against", "validated"], "counterexample")
        b, g, v = e["by"], e["against"], e["validated"]
        if not isinstance(b, str) or b not in PLAYERS:
            raise Invalid("unknown 'by' player")
        if not isinstance(g, str) or g not in PLAYERS:
            raise Invalid("unknown 'against' player")
        if not isinstance(v, bool):
            raise Invalid("validated must be boolean")
        if b == g:
            raise Invalid("by and against must differ")
        if (b, g) in seen:
            raise Invalid("duplicate counterexample pair")
        seen.add((b, g))
    fo = doc["forfeits"]
    if not isinstance(fo, list) or not all(isinstance(p, str) and p in PLAYERS for p in fo):
        raise Invalid("forfeits must be an array of known players")
    if len(set(fo)) != len(fo):
        raise Invalid("duplicate forfeit")


def score_round(doc):
    fo = set(doc["forfeits"])
    breaks = {p: 0 for p in PLAYERS}
    for e in doc["counterexamples"]:
        if e["validated"] and e["by"] not in fo and e["against"] not in fo:
            breaks[e["by"]] += 1
    points = {p: 0 for p in PLAYERS}
    elig = [p for p in PLAYERS if p not in fo]
    elig.sort(key=lambda p: (-doc["hidden_tests"][p]["passed"], -breaks[p]))
    slots = [3, 2, 1]
    i = 0
    while i < len(elig):
        key = lambda p: (doc["hidden_tests"][p]["passed"], breaks[p])
        j = i
        while j < len(elig) and key(elig[j]) == key(elig[i]):
            j += 1
        share = sum(slots[i:j]) / (j - i)
        for p in elig[i:j]:
            points[p] = share
        i = j
    return points, breaks


def jn(x):
    return int(x) if x == int(x) else float(x)


def num(x):
    return str(int(x)) if x == int(x) else repr(float(x))


def main(argv):
    ap = argparse.ArgumentParser(prog="hub_scoreboard.py", allow_abbrev=False)
    ap.add_argument("--results", action="append", required=True)
    ap.add_argument("--format", choices=["table", "json"], default="table")
    try:
        args = ap.parse_args(argv)
    except SystemExit as e:
        return 2 if e.code else 0
    try:
        rounds = {}
        for path in args.results:
            doc = load(path)
            validate(doc)
            if doc["round_id"] in rounds:
                raise Invalid("duplicate round_id %r" % doc["round_id"])
            rounds[doc["round_id"]] = score_round(doc)
    except Invalid as e:
        sys.stderr.write("error: %s\n" % e)
        return 2
    rids = sorted(rounds)
    tot = {p: sum(rounds[r][0][p] for r in rids) for p in PLAYERS}
    brk = {p: sum(rounds[r][1][p] for r in rids) for p in PLAYERS}
    place = {p: 1 + sum(1 for q in PLAYERS if tot[q] > tot[p]) for p in PLAYERS}
    order = sorted(PLAYERS, key=lambda p: (place[p], p))
    if args.format == "json":
        out = {"standings": [
            {"place": place[p], "player": p, "points": jn(tot[p]), "breaks": brk[p],
             "rounds": {r: jn(rounds[r][0][p]) for r in rids}} for p in order]}
        sys.stdout.write(json.dumps(out, indent=2, ensure_ascii=False) + "\n")
    else:
        rows = [["place", "player", "points", "breaks"] + rids]
        for p in order:
            rows.append([str(place[p]), p, num(tot[p]), str(brk[p])]
                        + [num(rounds[r][0][p]) for r in rids])
        w = [max(len(r[c]) for r in rows) for c in range(len(rows[0]))]
        lines = ["  ".join(c.ljust(w[i]) for i, c in enumerate(r)).rstrip() for r in rows]
        sys.stdout.write("\n".join(lines) + "\n")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
